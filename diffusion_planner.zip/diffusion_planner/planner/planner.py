
import warnings
import torch
import numpy as np
from typing import Deque, Dict, List, Type
import copy 

warnings.filterwarnings("ignore")

from nuplan.common.actor_state.ego_state import EgoState
from nuplan.common.utils.interpolatable_state import InterpolatableState
from nuplan.planning.simulation.trajectory.trajectory_sampling import TrajectorySampling
from nuplan.planning.simulation.trajectory.abstract_trajectory import AbstractTrajectory
from nuplan.planning.simulation.trajectory.interpolated_trajectory import InterpolatedTrajectory
from nuplan.planning.simulation.observation.observation_type import Observation, DetectionsTracks
from nuplan.planning.simulation.planner.ml_planner.transform_utils import transform_predictions_to_states
from nuplan.planning.simulation.planner.abstract_planner import (
    AbstractPlanner, PlannerInitialization, PlannerInput
)

from diffusion_planner.model.diffusion_planner import Diffusion_Planner
from diffusion_planner.data_process.data_processor import DataProcessor
from diffusion_planner.utils.config import Config

def identity(ego_state, predictions):
    return predictions


class DiffusionPlanner(AbstractPlanner):
    def __init__(
            self,
            config: Config,
            ckpt_path: str,

            past_trajectory_sampling: TrajectorySampling, 
            future_trajectory_sampling: TrajectorySampling,

            enable_ema: bool = True,
            device: str = "cpu",
        ):

        assert device in ["cpu", "cuda"], f"device {device} not supported"
        if device == "cuda":
            assert torch.cuda.is_available(), "cuda is not available"
            
        self._future_horizon = future_trajectory_sampling.time_horizon # [s] 
        self._step_interval = future_trajectory_sampling.time_horizon / future_trajectory_sampling.num_poses # [s]
        
        self._config = config
        self._ckpt_path = ckpt_path

        self._past_trajectory_sampling = past_trajectory_sampling
        self._future_trajectory_sampling = future_trajectory_sampling

        self._ema_enabled = enable_ema
        self._device = device

        self._planner = Diffusion_Planner(config)

        self.data_processor = DataProcessor(config)
        
        self.observation_normalizer = config.observation_normalizer

    def name(self) -> str:
        """
        Inherited.
        """
        return "diffusion_planner"
    
    def observation_type(self) -> Type[Observation]:
        """
        Inherited.
        """
        return DetectionsTracks

    def initialize(self, initialization: PlannerInitialization) -> None:
        """
        Inherited.
        """
        self._map_api = initialization.map_api
        self._route_roadblock_ids = initialization.route_roadblock_ids

        if self._ckpt_path is not None:
            state_dict:Dict = torch.load(self._ckpt_path, map_location=self._device)
            
            if self._ema_enabled:
                state_dict = state_dict['ema_state_dict']
            else:
                if "model" in state_dict.keys():
                    state_dict = state_dict['model']
            # use for ddp
            model_state_dict = {k[len("module."):]: v for k, v in state_dict.items() if k.startswith("module.")}
            self._planner.load_state_dict(model_state_dict)
        else:
            print("load random model")
        
        self._planner.eval()
        self._planner = self._planner.to(self._device)
        self._initialization = initialization

    def planner_input_to_model_inputs(self, planner_input: PlannerInput) -> Dict[str, torch.Tensor]:
        history = planner_input.history
        traffic_light_data = list(planner_input.traffic_light_data)
        model_inputs = self.data_processor.observation_adapter(history, traffic_light_data, self._map_api, self._route_roadblock_ids, self._device)

        return model_inputs

    def outputs_to_trajectory(self, outputs: Dict[str, torch.Tensor], ego_state_history: Deque[EgoState]) -> List[InterpolatableState]:    
        # here we take only the our ego vehicle's trajectory and discard others
        # check the format of outputs['prediction'] and use for the next prediction step
        predictions = outputs['prediction'][0, 0].detach().cpu().numpy().astype(np.float64) # T, 4
        heading = np.arctan2(predictions[:, 3], predictions[:, 2])[..., None]
        
        predictions = np.concatenate([predictions[..., :2], heading], axis=-1) 

        states = transform_predictions_to_states(predictions, ego_state_history, self._future_horizon, self._step_interval)

        return states


        ###################### change here ######################


    
    class MidOutput:
        def __init__(self, parent_trajectory : AbstractTrajectory, parent_outputs: Dict[str, torch.Tensor]):
            self.parent_trajectory = parent_trajectory
            self.parent_outputs = parent_outputs
            self.branch_trajectories = []
            self.branch_outputs = []
        def add_branch(self, branch_trajectory: AbstractTrajectory, branch_output: Dict[str, torch.Tensor]):
            self.branch_trajectories.append(branch_trajectory)
            self.branch_outputs.append(branch_output)




    def imaginary_input_history_consistent(self, original_inputs: Dict[str, torch.Tensor],parent_outputs: Dict[str, torch.Tensor],m_hist_steps: int = 1) -> Dict[str, torch.Tensor]:
        """
        Builds a new inputs dict whose last 2s (H frames) remains intact in length,
        but is rolled forward by `m_hist_steps`. The tail frames are filled with
        predicted states sampled at times aligned to the history Δt.

        Assumes:
        parent_outputs['prediction'] -> [B=1, P, T, 4] with ego at index 0.
        inputs contain keys: 'ego_agent_past' [1, H, D], 'ego_current_state' [1, 4],
                            'neighbor_agents_past' [1, Nmax, H, D], and masks.
        """
        
        return new_inputs



    def get_best_trajectory(self, trajectories: List[MidOutput]) -> AbstractTrajectory:
        """
        Select the best trajectory based on a simple heuristic (e.g., minimum distance to a reference path).
        This is a placeholder for more sophisticated selection logic.
        """
        # Placeholder: return the first trajectory

        return trajectories[0].parent_trajectory
    
    def compute_planner_trajectory(self, current_input: PlannerInput) -> AbstractTrajectory:
        """
        Inherited.
        """
        
        inputs = self.planner_input_to_model_inputs(current_input)

        inputs = self.observation_normalizer(inputs)    

        num_of_parents = 3
        num_of_branches = 3
        all_traj = []

        for i in range(num_of_parents):
            print("parent step:", i)
            _, outputs = self._planner(inputs)

            trajectory = InterpolatedTrajectory(
                    trajectory=self.outputs_to_trajectory(outputs, current_input.history.ego_states)
                )
            mo = self.MidOutput(trajectory, outputs)
            all_traj.append(mo)

            branch_input = self.imaginary_input_history_consistent( inputs, outputs, m_hist_steps=1)

            for j in range(num_of_branches):
                print("    branching step:", j)
                _, branch_outputs = self._planner(branch_input)

                branch_trajectory = InterpolatedTrajectory(
                        trajectory=self.outputs_to_trajectory(branch_outputs, current_input.history.ego_states)
                    )
                mo.add_branch(branch_trajectory, branch_outputs)
            

        return self.get_best_trajectory(all_traj)  
    





    